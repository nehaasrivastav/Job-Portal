import React, { useEffect, useState } from 'react'

export default function AllJobs() {

  let [apiData,setapiData]=useState([])

useEffect(()=>{
  fetch("http://localhost:5000/All-Jobs")
  .then((res)=>res.json())
  .then((data)=>{
    // console.log(data)
        setapiData(data)
  
  })
},[])

console.log(apiData)

  return (
    <div>
      <h2>All Jobs</h2>
      {/* {
       data.map((val)=>{
       <h1>company:{val.company}</h1>
        })
      } */}
    </div>
  )
}
