import React, { useState } from 'react'

export default function Login() {

    const [email,setemail]=useState("")
    const[password,setpassword]=useState("")
  return (
    <div>
      <label>Email:
                    <input type='email' value={email} onChange={(e) => {setemail(e.target.value) }} placeholder='enter your email'></input>
                </label>
                <br />
                <label>Password:
                    <input type='text' value={password} onChange={(e) => {setpassword(e.target.value) }} placeholder='enter your password'></input>
                </label>
    </div>
  )
}
