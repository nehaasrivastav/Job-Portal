import React from 'react'
import './style.css'

export default function Homepage() {
  return (
    <div>
      <h1>home</h1>
      <div className='container-fluid' id='first-box'>
      </div>
    </div>
  )
}
